Hi, thanks for downloading this!

The windows version is much more 'in Beta' than the mac version.
Sorry about that, I don't develop for windows much. The next version will be better.

Couple of 'Windows bugs':
The file outside the 'dist' folder SHOULD be a shortcut that will launch the program
if not the file is dist\VidiiUStreamer.exe it needs to be run inside this folder with all the stuff around it.
(Again, sorry about that. Hopefully the shortcut works though.)

When the program is generating the thumbnails there'll be two console windows running ffmpeg dancing around
(ffmpeg is a video file utility that will eventually allow the program to send ANY video file to the WiiU).
They might be dancing for a while if you've got tons of video files. That'll get fixed next version.

Couple of general warnings:
The program will seem to crash when the server is running, this'll be fixed in a rewrite of the GUI next version and you don't need to worry about it.

If you run into any weird bugs I've not mentioned send an email to support@vidiiustreamer.com and i'll add it to the list

Erm, hope the program works well for you - I've started using it myself quite a lot.

It checks for new programs every time you visit the page so you don't need to worry about that.
It checks if you're running the latest version when you launch it so hopefully once I fix things you'll hear about it.

Thanks again.